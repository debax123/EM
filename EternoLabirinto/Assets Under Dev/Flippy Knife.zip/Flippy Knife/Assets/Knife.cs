﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

public class Knife : MonoBehaviour
{
    Vector3 touchPosition;
    Vector3 releasePosition;
    public Rigidbody knifeRb;

    public float launchForce;
    public Vector3 torqueForce;

    float timeInAir;
    bool isInAir;

    public Text scoreText;
    int score;

    //void Save()
    //{
    //    Save save = new Save();
    //    save.score = score;
    //    save.knifeX = transform.position.x;
    //    save.knifeY = transform.position.y;
    //    save.knifeZ = transform.position.z;

    //    BinaryFormatter bf = new BinaryFormatter();
    //    FileStream file = File.Create(Application.persistentDataPath + "/meusave.save");
    //    bf.Serialize(file, save);
    //    file.Close();
    //}

    //void Load()
    //{
    //    string URL = Application.persistentDataPath + "/meusave.save";
    //    BinaryFormatter bf = new BinaryFormatter();
    //    Save save = null;

    //    if (File.Exists(URL))
    //    {
    //        FileStream file = File.Open(URL, FileMode.Open);
    //        save = (Save)bf.Deserialize(file);
    //    }

    //    score = save.score;
    //    transform.position = new Vector3(save.knifeX, save.knifeY, save.knifeZ);
    //}

    void Update()
    {
        if (isInAir)
            timeInAir += Time.deltaTime;

        if (Input.GetMouseButtonDown(0))
        {
            touchPosition = Camera.main.ScreenToViewportPoint(Input.mousePosition);
        }

        if (Input.GetMouseButtonUp(0))
        {
            releasePosition = Camera.main.ScreenToViewportPoint(Input.mousePosition);
            Launch();
        }
    }

    void Launch()
    {
        isInAir = true;
        knifeRb.isKinematic = false;
        knifeRb.AddForce((releasePosition - touchPosition) * launchForce, ForceMode.Impulse);
        knifeRb.AddRelativeTorque(torqueForce, ForceMode.Impulse);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Wood"))
        {
            timeInAir = 0;
            isInAir = false;
            knifeRb.isKinematic = true;
            score++;

            if (PlayerPrefs.GetInt("HighScore") < score)
                PlayerPrefs.SetInt("HighScore", score);

            scoreText.text = "Score: " + score + "\n" + "HighScore: " + PlayerPrefs.GetInt("HighScore");
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (timeInAir > 0.3f)
            SceneManager.LoadScene(0);
    }
}
