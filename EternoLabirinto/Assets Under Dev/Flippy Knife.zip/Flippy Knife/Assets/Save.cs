﻿[System.Serializable]
public class Save 
{
    public int score;
    public float knifeX;
    public float knifeY;
    public float knifeZ;
}
